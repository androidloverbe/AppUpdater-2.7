package com.github.javiersantos.appupdater.enums;

public enum Duration {
    NORMAL,
    INDEFINITE
}
